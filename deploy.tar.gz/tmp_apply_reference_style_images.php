<?php
require __DIR__ . '/vendor/autoload.php';
$app = require __DIR__ . '/bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

use App\Models\Product;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

$targets = [
    'Gut Reset Daily Capsules',
    'Gut Reset Probiotic Blend',
    'Gut Reset Morning Tea',
];

$svg = <<<'SVG'
<svg xmlns="http://www.w3.org/2000/svg" width="1536" height="1152" viewBox="0 0 1536 1152" role="img" aria-label="Minimal supplement bottle on warm beige background">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#f6ead9"/>
      <stop offset="100%" stop-color="#e9d7c0"/>
    </linearGradient>
    <linearGradient id="bottle" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#fffaf2"/>
      <stop offset="100%" stop-color="#f0e3cf"/>
    </linearGradient>
    <linearGradient id="label" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#f7f1e7"/>
      <stop offset="100%" stop-color="#efe2cf"/>
    </linearGradient>
    <filter id="soft" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="12"/>
    </filter>
    <filter id="shadow" x="-30%" y="-30%" width="160%" height="160%">
      <feDropShadow dx="0" dy="18" stdDeviation="20" flood-color="#8a755b" flood-opacity="0.22"/>
    </filter>
  </defs>

  <rect width="1536" height="1152" fill="url(#bg)"/>

  <ellipse cx="780" cy="830" rx="540" ry="95" fill="#d9c4aa" opacity="0.45" filter="url(#soft)"/>

  <path d="M120 180 C280 80, 420 240, 610 120" stroke="#b9a184" stroke-width="36" stroke-linecap="round" opacity="0.18" fill="none" filter="url(#soft)"/>
  <path d="M1040 130 C1170 20, 1360 180, 1480 80" stroke="#a88f72" stroke-width="28" stroke-linecap="round" opacity="0.14" fill="none" filter="url(#soft)"/>

  <rect x="905" y="530" width="260" height="230" fill="#ddc4a5" opacity="0.7"/>
  <rect x="930" y="500" width="220" height="240" fill="#ead5ba"/>

  <g filter="url(#shadow)">
    <rect x="575" y="275" width="385" height="515" rx="120" fill="url(#bottle)"/>
    <rect x="610" y="248" width="315" height="90" rx="28" fill="#f7ebd9"/>
    <rect x="610" y="248" width="315" height="40" rx="18" fill="#fff7eb" opacity="0.85"/>
    <rect x="625" y="430" width="285" height="205" rx="28" fill="url(#label)"/>
  </g>

  <rect x="300" y="740" width="205" height="160" fill="#f2e7d7" stroke="#e7d7c1" stroke-width="8"/>
  <rect x="294" y="734" width="205" height="160" fill="#fff6ea" opacity="0.48"/>

  <path d="M620 430 C665 410, 720 405, 795 410" stroke="#d6c3a8" stroke-width="6" opacity="0.5"/>
  <path d="M620 650 C700 672, 792 670, 900 646" stroke="#d8c5ab" stroke-width="5" opacity="0.4"/>
</svg>
SVG;

Storage::disk('public')->makeDirectory('products');

foreach ($targets as $name) {
    $product = Product::where('name', $name)->first();
    if (!$product) {
        echo "Skipped: {$name} (not found)" . PHP_EOL;
        continue;
    }

    $variant = $product->variants()->first();
    if (!$variant) {
        echo "Skipped: {$name} (no variant)" . PHP_EOL;
        continue;
    }

    $existingImages = $variant->images()->with('media')->get();
    foreach ($existingImages as $existingImage) {
      $mediaIdToDelete = $existingImage->media?->id;
      $mediaPathToDelete = $existingImage->media?->storage_path;

      $existingImage->delete();

      if ($mediaPathToDelete) {
        Storage::disk('public')->delete($mediaPathToDelete);
      }
      if ($mediaIdToDelete) {
        DB::table('media')->where('id', $mediaIdToDelete)->delete();
      }
    }

    $filename = Str::slug($product->name) . '-style.svg';
    $relativePath = 'products/' . $filename;
    Storage::disk('public')->put($relativePath, $svg);

    $mediaId = DB::table('media')->insertGetId([
        'uuid' => (string) Str::uuid(),
        'file_name' => $filename,
        'storage_path' => $relativePath,
        'mime_type' => 'image/svg+xml',
        'file_size' => strlen($svg),
        'width' => 1536,
        'height' => 1152,
        'alt_text' => $product->name,
        'uploaded_by' => null,
        'created_at' => now(),
    ]);

    $variant->images()->create([
        'media_id' => $mediaId,
        'image_type' => 'gallery',
        'sort_order' => 0,
        'alt_text' => $product->name,
        'is_primary' => true,
    ]);

    echo "Updated image: {$name}" . PHP_EOL;
}
