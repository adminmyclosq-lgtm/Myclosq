<?php

return [
    'default' => env('MAIL_MAILER','log'),
    'mailers' => ['log'=>['transport'=>'log'],'array'=>['transport'=>'array'],'smtp'=>['transport'=>'smtp','host'=>env('MAIL_HOST','127.0.0.1'),'port'=>env('MAIL_PORT',2525),'username'=>env('MAIL_USERNAME'),'password'=>env('MAIL_PASSWORD'),'timeout'=>null,'local_domain'=>env('MAIL_EHLO_DOMAIN')]],
    'from' => ['address'=>env('MAIL_FROM_ADDRESS','hello@example.com'),'name'=>env('MAIL_FROM_NAME','Gut Reset')],
];
