<?php $__env->startSection('content'); ?>
<?php
    $page = \App\Models\CmsPage::where('slug', 'support')->with('sections.media')->first();
?>
<?php if(isset($page) && $page->sections && $page->sections->count() > 0): ?>
    <?php $__currentLoopData = $page->sections->sortBy('sort_order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $contentData = is_string($section->content) ? json_decode($section->content, true) : ($section->content ?? []);
            if (!is_array($contentData)) $contentData = [];
            $settings = $contentData['settings'] ?? [];
            if (!empty($settings['hidden_desktop']) && !empty($settings['hidden_mobile'])) continue;
        ?>

        <?php if($section->section_type === 'support_hero'): ?>
            <section class="py-16 md:py-20 text-center">
                <div class="mx-auto w-full max-w-[1200px] px-5 sm:px-8">
                    <div class="text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground">Support</div>
                    <h1 class="mt-4 font-serif text-5xl leading-[1.05] md:text-6xl"><?php echo e($section->title); ?></h1>
                    <p class="mx-auto mt-4 max-w-xl text-[15px] text-foreground/70"><?php echo e($section->subtitle); ?></p>
                    
                    <div class="mx-auto mt-10 grid max-w-4xl gap-4 md:grid-cols-4">
                        <?php $__currentLoopData = $contentData['cards'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="rounded-xl border border-border/60 bg-card p-5 text-[14px] text-foreground/70 hover:bg-cream transition cursor-pointer"><?php echo e(is_array($card) ? $card['title'] ?? '' : $card); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
        
        <?php elseif($section->section_type === 'support_purchase_origin'): ?>
            <section class="bg-cream/60 py-24 lg:py-32">
                <div class="mx-auto w-full max-w-[1200px] px-5 sm:px-8">
                    <h2 class="text-center font-serif text-3xl leading-tight md:text-4xl"><?php echo e($section->title); ?></h2>
                    <div class="mx-auto mt-12 grid max-w-4xl gap-6 md:grid-cols-2">
                        <div class="rounded-2xl bg-background p-8">
                            <div class="font-serif text-xl border-l-[3px] border-primary pl-4"><?php echo e($contentData['col1_title'] ?? ''); ?></div>
                            <p class="mt-4 text-[14px] text-foreground/60 pl-4"><?php echo e($contentData['col1_text'] ?? ''); ?></p>
                            <div class="mt-8 pl-4">
                                <a class="btn-primary" href="<?php echo e($contentData['col1_btn_url'] ?? '#'); ?>"><?php echo e($contentData['col1_btn'] ?? 'Get help with your order'); ?></a>
                            </div>
                        </div>
                        <div class="rounded-2xl bg-background p-8">
                            <div class="font-serif text-xl border-l-[3px] border-border pl-4"><?php echo e($contentData['col2_title'] ?? ''); ?></div>
                            <p class="mt-4 text-[14px] text-foreground/60 pl-4"><?php echo e($contentData['col2_text'] ?? ''); ?></p>
                            <div class="mt-8 pl-4">
                                <a class="btn-secondary" href="<?php echo e($contentData['col2_btn_url'] ?? '#'); ?>"><?php echo e($contentData['col2_btn'] ?? 'Get Amazon Help'); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        
        <?php elseif($section->section_type === 'support_topics'): ?>
            <section class="py-24 lg:py-32">
                <div class="mx-auto w-full max-w-[1200px] px-5 sm:px-8">
                    <h2 class="text-center font-serif text-3xl leading-tight md:text-4xl"><?php echo e($section->title); ?></h2>
                    <div class="mx-auto mt-14 grid max-w-5xl gap-10 md:grid-cols-4">
                        <?php $__currentLoopData = $contentData['topics'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <div class="text-[12px] font-medium uppercase tracking-[0.14em] text-primary"><?php echo e($topic['title'] ?? ''); ?></div>
                                <ul class="mt-5 space-y-3 text-[14px] text-foreground/70">
                                    <?php $__currentLoopData = $topic['items'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>&middot; <?php echo e(is_array($item) ? $item['title'] ?? '' : $item); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
        
        <?php elseif($section->section_type === 'support_course_start'): ?>
            <section class="bg-cream/60 py-24 lg:py-32">
                <div class="mx-auto w-full max-w-[1200px] px-5 sm:px-8">
                    <h2 class="text-center font-serif text-3xl leading-tight md:text-4xl"><?php echo e($section->title); ?></h2>
                    <div class="mx-auto mt-12 grid max-w-4xl gap-6 md:grid-cols-3">
                        <?php $__currentLoopData = $contentData['cards'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="rounded-xl bg-background p-8 text-center flex flex-col items-center">
                                <div class="grid h-10 w-10 place-items-center rounded-full bg-primary/10 text-primary font-semibold text-lg"><?php echo e($index + 1); ?></div>
                                <div class="mt-5 font-serif text-lg"><?php echo e($card['title'] ?? ''); ?></div>
                                <div class="mt-3 text-[14px] text-foreground/60 leading-relaxed max-w-[200px]"><?php echo e($card['text'] ?? ''); ?></div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="mt-12 flex justify-center gap-4">
                        <a href="<?php echo e($contentData['button_1_url'] ?? '#'); ?>" class="btn-primary"><?php echo e($contentData['button_1'] ?? 'Activate Course'); ?></a>
                        <a href="<?php echo e($contentData['button_2_url'] ?? '#'); ?>" class="btn-secondary"><?php echo e($contentData['button_2'] ?? 'Contact Us'); ?></a>
                    </div>
                </div>
            </section>
        
        <?php elseif($section->section_type === 'support_concerns'): ?>
            <section class="py-24 lg:py-32">
                <div class="mx-auto w-full max-w-[1200px] px-5 sm:px-8">
                    <h2 class="text-center font-serif text-3xl leading-tight md:text-4xl"><?php echo nl2br(e($section->title)); ?></h2>
                    <div class="mx-auto mt-12 grid max-w-4xl gap-6 md:grid-cols-2">
                        <div class="rounded-2xl border border-border/60 bg-card p-10 flex flex-col justify-between">
                            <div>
                                <div class="text-[12px] font-medium uppercase tracking-[0.18em] text-muted-foreground"><?php echo e($contentData['col1_badge'] ?? 'Report a product concern'); ?></div>
                                <p class="mt-4 text-[15px] leading-relaxed text-foreground/70"><?php echo e($contentData['col1_text'] ?? ''); ?></p>
                            </div>
                            <div class="mt-8">
                                <a class="btn-primary" href="<?php echo e($contentData['col1_btn_url'] ?? '#'); ?>"><?php echo e($contentData['col1_btn'] ?? 'Report Now'); ?></a>
                            </div>
                        </div>
                        <div class="rounded-2xl border border-destructive/30 bg-destructive/[0.04] p-10 flex flex-col justify-between">
                            <div>
                                <div class="text-[12px] font-medium uppercase tracking-[0.18em] text-muted-foreground"><span class="text-destructive"><?php echo e($contentData['col2_badge'] ?? 'Seek professional guidance first'); ?></span></div>
                                <p class="mt-4 text-[15px] leading-relaxed text-foreground/70"><?php echo e($contentData['col2_text'] ?? ''); ?></p>
                            </div>
                            <div class="mt-8">
                                <a href="<?php echo e($contentData['col2_btn_url'] ?? '/our-standards'); ?>" class="btn-secondary"><?php echo e($contentData['col2_btn'] ?? 'Read Safety Standards'); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        
        <?php elseif($section->section_type === 'support_contact_methods'): ?>
            <section class="bg-cream/60 py-20 lg:py-24">
                <div class="mx-auto w-full max-w-[1200px] px-5 sm:px-8">
                    <div class="mx-auto grid max-w-5xl gap-6 md:grid-cols-3">
                        <?php $__currentLoopData = $contentData['cards'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="rounded-2xl bg-background p-8 flex flex-col h-full">
                                <div class="font-serif text-xl border-l-[3px] <?php echo e($index === 0 ? 'border-[#25d366]' : 'border-primary'); ?> pl-4"><?php echo e($card['title'] ?? ''); ?></div>
                                <div class="mt-4 text-[14px] text-foreground/60 pl-4 flex-grow"><?php echo e($card['text'] ?? ''); ?></div>
                                <div class="mt-8 pl-4">
                                    <a class="btn-secondary" href="<?php echo e($card['url'] ?? '#'); ?>"><?php echo e($card['btn'] ?? 'Open'); ?></a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
        
        <?php elseif($section->section_type === 'support_details_ready'): ?>
            <section class="py-20 lg:py-24">
                <div class="mx-auto w-full max-w-[1200px] px-5 sm:px-8">
                    <div class="mx-auto max-w-4xl rounded-2xl border border-primary/20 bg-primary/5 p-8 md:p-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
                        <div>
                            <div class="font-serif text-2xl"><?php echo e($section->title); ?></div>
                            <div class="mt-2 text-[14px] text-foreground/70"><?php echo e($section->subtitle); ?></div>
                        </div>
                        <ul class="shrink-0 space-y-3 text-[14px] text-foreground/70 font-medium">
                            <?php $__currentLoopData = $contentData['items'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>&bull; <?php echo e($item['label'] ?? ''); ?> <span class="font-normal opacity-70"><?php echo e($item['hint'] ?? ''); ?></span></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </section>
        
        <?php elseif($section->section_type === 'support_faq'): ?>
            <section class="py-24 lg:py-32">
                <div class="mx-auto w-full max-w-[1200px] px-5 sm:px-8 mx-auto max-w-3xl">
                    <h2 class="text-center font-serif text-3xl leading-tight md:text-4xl"><?php echo e($section->title); ?></h2>
                    <div class="mt-12 divide-y divide-border/70 border-t border-b border-border/70">
                        <?php $__currentLoopData = $contentData['items'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <details class="group">
                            <summary class="flex cursor-pointer list-none items-center justify-between gap-4 py-5 text-left font-medium [&::-webkit-details-marker]:hidden">
                                <span class="text-[15px] text-foreground group-hover:text-primary transition-colors"><?php echo e($item['q'] ?? ''); ?></span>
                                <span class="text-foreground/40 transition-transform duration-300 group-open:rotate-45 text-2xl shrink-0">+</span>
                            </summary>
                            <div class="pb-6 pr-8 text-[14px] leading-relaxed text-foreground/70"><?php echo e($item['a'] ?? ''); ?></div>
                        </details>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
        
        <?php elseif($section->section_type === 'support_auth_cta'): ?>
            <section class="bg-primary text-primary-foreground">
                <div class="mx-auto w-full max-w-[1200px] px-5 sm:px-8 py-24 text-center">
                    <h2 class="font-serif text-3xl md:text-4xl"><?php echo e($section->title); ?></h2>
                    <p class="mx-auto mt-5 max-w-md text-[15px] text-primary-foreground/80 leading-relaxed"><?php echo e($section->subtitle); ?></p>
                    <div class="mt-8">
                        <a href="<?php echo e($contentData['button_url'] ?? '/login'); ?>" class="btn-primary !bg-background !text-foreground hover:!bg-background/90"><?php echo e($contentData['button'] ?? 'Log in'); ?></a>
                    </div>
                </div>
            </section>
        
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Support - Guided Wellness'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gutreset\resources\views/support.blade.php ENDPATH**/ ?>