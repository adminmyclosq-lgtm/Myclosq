<?php $__env->startSection('content'); ?>
<?php
    $page = \App\Models\CmsPage::where('slug', 'learn')->with('sections.media')->first();
    if (!function_exists('resolveImg')) {
        function resolveImg($path, $fallback) {
            $path = $path ?: $fallback;
            if (str_starts_with($path, 'assets/')) return 'https://guided-gut-reset-lovable-app.lovable.app/' . $path;
            return asset($path);
        }
    }
?>
<?php if(isset($page) && $page->sections && $page->sections->count() > 0): ?>
    <?php $__currentLoopData = $page->sections->sortBy('sort_order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $contentData = is_string($section->content) ? json_decode($section->content, true) : ($section->content ?? []);
            if (!is_array($contentData)) $contentData = [];
            $settings = $contentData['settings'] ?? [];
            if (!empty($settings['hidden_desktop']) && !empty($settings['hidden_mobile'])) continue;
        ?>

        <?php if($section->section_type === 'learn_hero'): ?>
            <section class="border-b border-border/60">
                <div class="mx-auto w-full max-w-[1200px] px-5 sm:px-8 grid gap-10 py-20 md:py-32 lg:grid-cols-[1.05fr_1fr] lg:gap-14">
                    <div>
                        <div class="text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground">Learn</div>
                        <h1 class="mt-4 font-serif text-5xl leading-[1.05] md:text-6xl"><?php echo e($section->title); ?></h1>
                        <p class="mt-6 max-w-md text-[15px] leading-relaxed text-foreground/70"><?php echo e($section->subtitle); ?></p>
                        <div class="mt-8 flex gap-3">
                            <a href="<?php echo e($contentData['button_1_url'] ?? '#'); ?>" class="btn-primary"><?php echo e($contentData['button_1'] ?? ''); ?></a>
                            <a href="<?php echo e($contentData['button_2_url'] ?? '#'); ?>" class="btn-secondary"><?php echo e($contentData['button_2'] ?? ''); ?></a>
                        </div>
                    </div>
                    <div class="overflow-hidden rounded-2xl bg-cream min-h-[400px]">
                        <?php if($section->media): ?>
                            <img src="<?php echo e($section->media->storage_path ? asset('storage/'.$section->media->storage_path) : $section->media->url); ?>" alt="<?php echo e($section->title); ?>" class="h-full w-full object-cover"/>
                        <?php else: ?>
                            <img src="<?php echo e(resolveImg($contentData['image'] ?? '', 'assets/hero-product-CftTmpl1.jpg')); ?>" alt="Learn" class="h-full w-full object-cover"/>
                        <?php endif; ?>
                    </div>
                </div>
            </section>
        
        <?php elseif($section->section_type === 'learn_start_understanding'): ?>
            <section class="py-24 lg:py-32">
                <div class="mx-auto w-full max-w-[1200px] px-5 sm:px-8">
                    <h2 class="text-center font-serif text-3xl leading-tight md:text-4xl"><?php echo e($section->title); ?></h2>
                    <div class="mt-12 grid gap-6 md:grid-cols-3">
                        <?php $__currentLoopData = $contentData['cards'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="block rounded-2xl border border-border/60 bg-card p-8 transition hover:bg-cream/60" href="<?php echo e($card['url'] ?? '#'); ?>">
                                <div class="font-serif text-lg uppercase tracking-[0.14em]"><?php echo e($card['title'] ?? ''); ?></div>
                                <p class="mt-4 text-[14px] leading-relaxed text-foreground/60"><?php echo e($card['text'] ?? ''); ?></p>
                                <div class="mt-6 text-[12px] uppercase tracking-[0.14em] text-primary font-medium"><?php echo e($card['btn'] ?? 'Read the guide →'); ?></div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
        
        <?php elseif($section->section_type === 'learn_product_trials'): ?>
            <section class="bg-cream/60 py-24 lg:py-32">
                <div class="mx-auto w-full max-w-[1200px] px-5 sm:px-8 grid items-center gap-14 lg:grid-cols-[1fr_1fr] lg:gap-20">
                    <div class="overflow-hidden rounded-2xl bg-background min-h-[400px]">
                        <?php if($section->media): ?>
                            <img src="<?php echo e($section->media->storage_path ? asset('storage/'.$section->media->storage_path) : $section->media->url); ?>" alt="<?php echo e($section->title); ?>" class="h-full w-full object-cover"/>
                        <?php else: ?>
                            <img src="<?php echo e(resolveImg($contentData['image'] ?? '', 'assets/bottle-capsules-COsDFlLa.jpg')); ?>" alt="Trial" class="h-full w-full object-cover"/>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div class="text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground"><?php echo e($contentData['badge'] ?? 'Product Trials'); ?></div>
                        <h3 class="mt-4 font-serif text-3xl leading-tight md:text-4xl"><?php echo e($section->title); ?></h3>
                        <p class="mt-6 max-w-md text-[15px] leading-relaxed text-foreground/70"><?php echo e($section->subtitle); ?></p>
                        <div class="mt-8">
                            <a class="btn-primary" href="<?php echo e($contentData['button_1_url'] ?? '#'); ?>"><?php echo e($contentData['button_1'] ?? 'Read the guide →'); ?></a>
                        </div>
                    </div>
                </div>
            </section>
        
        <?php elseif($section->section_type === 'learn_guides_grid'): ?>
            <section class="py-24 lg:py-32">
                <div class="mx-auto w-full max-w-[1200px] px-5 sm:px-8">
                    <?php if($section->title): ?>
                    <h2 class="text-center font-serif text-3xl leading-tight md:text-4xl mb-12"><?php echo e($section->title); ?></h2>
                    <?php endif; ?>
                    <div class="grid gap-8 md:grid-cols-3">
                        <?php $__currentLoopData = $contentData['cards'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="group block" href="<?php echo e($card['url'] ?? '#'); ?>">
                                <div class="overflow-hidden rounded-2xl bg-cream">
                                    <img src="<?php echo e(resolveImg($card['image'] ?? '', 'assets/hero-product-CftTmpl1.jpg')); ?>" alt="" class="aspect-[4/3] w-full object-cover transition duration-500 group-hover:scale-[1.03]"/>
                                </div>
                                <div class="mt-5">
                                    <div class="text-[11px] font-medium uppercase tracking-[0.14em] text-primary"><?php echo e($card['tag'] ?? ''); ?></div>
                                    <div class="mt-3 font-serif text-xl leading-snug"><?php echo e($card['title'] ?? ''); ?></div>
                                    <div class="mt-3 text-[12px] font-medium uppercase tracking-[0.14em] text-foreground/50 group-hover:text-primary transition-colors"><?php echo e($card['btn'] ?? 'Read the guide →'); ?></div>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
        
        <?php elseif($section->section_type === 'learn_language_clarity'): ?>
            <section class="bg-primary text-primary-foreground py-24 lg:py-32">
                <div class="mx-auto w-full max-w-[1200px] px-5 sm:px-8 grid gap-12 lg:grid-cols-[1fr_1.5fr] lg:gap-20">
                    <div>
                        <h2 class="font-serif text-3xl leading-tight md:text-4xl"><?php echo e($section->title); ?></h2>
                        <p class="mt-6 max-w-sm text-[15px] leading-relaxed text-primary-foreground/80"><?php echo e($section->subtitle); ?></p>
                    </div>
                    <div class="grid gap-5 sm:grid-cols-2">
                        <?php $__currentLoopData = $contentData['cards'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="rounded-xl border border-primary-foreground/15 bg-primary-foreground/[0.05] p-6">
                                <div class="text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground"><span class="text-primary-foreground/70"><?php echo e($card['badge'] ?? ''); ?></span></div>
                                <p class="mt-3 text-[14px] leading-relaxed text-primary-foreground/85"><?php echo e($card['text'] ?? ''); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="lg:col-span-2 mt-4">
                        <a href="<?php echo e($contentData['button_1_url'] ?? '#'); ?>" class="btn-secondary !border-primary-foreground/30 !text-primary-foreground hover:!bg-primary-foreground/10"><?php echo e($contentData['button_1'] ?? 'Review Our Standards'); ?></a>
                    </div>
                </div>
            </section>
        
        <?php elseif($section->section_type === 'learn_cta'): ?>
            <section class="bg-cream/60 py-24 lg:py-32 text-center">
                <div class="mx-auto w-full max-w-[1200px] px-5 sm:px-8">
                    <div class="text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground"><?php echo e($contentData['badge'] ?? 'Ready when you are'); ?></div>
                    <h2 class="mx-auto mt-5 max-w-2xl font-serif text-3xl leading-tight md:text-4xl"><?php echo e($section->title); ?></h2>
                    <p class="mx-auto mt-6 max-w-md text-[15px] leading-relaxed text-foreground/70"><?php echo e($section->subtitle); ?></p>
                    <div class="mt-8 flex flex-wrap justify-center gap-3">
                        <a href="<?php echo e($contentData['button_1_url'] ?? '#'); ?>" class="btn-primary"><?php echo e($contentData['button_1'] ?? ''); ?></a>
                        <a href="<?php echo e($contentData['button_2_url'] ?? '#'); ?>" class="btn-secondary"><?php echo e($contentData['button_2'] ?? ''); ?></a>
                    </div>
                </div>
            </section>
        
        <?php elseif($section->section_type === 'learn_footer_note'): ?>
            <section class="border-t border-border/60 py-10">
                <div class="mx-auto w-full max-w-[1200px] px-5 sm:px-8 flex flex-col items-center justify-between gap-4 text-[13px] text-foreground/60 sm:flex-row">
                    <div><?php echo e($contentData['text'] ?? 'Some symptoms should not wait for a product trial.'); ?></div>
                    <div class="flex flex-wrap items-center gap-6">
                        <?php $__currentLoopData = $contentData['links'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($link['url'] ?? '#'); ?>" class="underline hover:text-foreground transition-colors"><?php echo e($link['title'] ?? ''); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Learn - Guided Wellness'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gutreset\resources\views/learn.blade.php ENDPATH**/ ?>