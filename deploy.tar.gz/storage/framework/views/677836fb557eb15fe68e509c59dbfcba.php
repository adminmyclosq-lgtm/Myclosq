<div>
    <?php
        $html = is_string($section->content) ? (json_decode($section->content, true)['html'] ?? '') : ($section->content['html'] ?? '');
    ?>
    
    <?php echo $html; ?>

</div>
<?php /**PATH C:\xampp\htdocs\gutreset\resources\views/components/sections/custom_html.blade.php ENDPATH**/ ?>