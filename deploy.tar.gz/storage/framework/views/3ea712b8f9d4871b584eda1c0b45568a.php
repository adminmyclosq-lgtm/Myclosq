<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['section']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['section']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $content = is_string($section->content) ? json_decode($section->content, true) : ($section->content ?? []);
    if (!is_array($content)) $content = [];
    $settings = $content['settings'] ?? [];
    
    $badge = $content['badge'] ?? 'The problem';
    $cards = $content['cards'] ?? ['No clear starting point', 'Real-life disruptions get read as failure', 'The most recent moment becomes the impression'];
    
    $topStyle = isset($settings['top_spacing']) && $settings['top_spacing'] ? "padding-top: {$settings['top_spacing']};" : "padding-top: 80px;";
    $bottomStyle = isset($settings['bottom_spacing']) && $settings['bottom_spacing'] ? "padding-bottom: {$settings['bottom_spacing']};" : "padding-bottom: 80px;";
    
    if (!empty($settings['hidden'])) return;
?>
<section class="border-t border-border/60 bg-background">
    <div class="section grid gap-10 lg:grid-cols-[1fr_1fr] lg:gap-16 lg:items-center">
        <div class="overflow-hidden rounded-2xl bg-cream">
            <?php if($section->media): ?>
                <img src="<?php echo e($section->media->storage_path ? asset('storage/'.$section->media->storage_path) : $section->media->url); ?>" alt="<?php echo e($section->title); ?>" class="h-full w-full object-cover">
            <?php else: ?>
                <div class="flex aspect-square md:aspect-auto w-full md:h-full min-h-[400px] items-center justify-center border-2 border-dashed border-stone-300 bg-[var(--panel)] text-stone-400 backdrop-blur text-sm">
                    Image pending uploading from CMS
                </div>
            <?php endif; ?>
        </div>
        <div>
            <div class="badge mb-4"><?php echo e($badge); ?></div>
            <h2 class="font-serif text-4xl leading-[1.1] text-foreground md:text-5xl"><?php echo $section->title ?? 'Most gut resets leave you guessing.'; ?></h2>
            <p class="mt-6 max-w-md text-[15px] leading-relaxed text-foreground/70"><?php echo e($section->subtitle); ?></p>
            
            <?php if(!empty($cards)): ?>
            <ul class="mt-8 space-y-4 text-[14px] text-foreground/75">
                <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="flex gap-3">
                        <span class="mt-2 h-1 w-1 shrink-0 rounded-full bg-primary"></span> 
                        <span><?php echo e(is_array($card) ? ($card['title'] ?? '') : $card); ?></span>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\gutreset\resources\views/components/sections/problem.blade.php ENDPATH**/ ?>