<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title ?? 'Sign in - Guided Wellness'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="min-h-screen bg-white text-[var(--ink)]">
    <?php if (isset($component)) { $__componentOriginalfdc8967a87956c0a7185abbef03fae20 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfdc8967a87956c0a7185abbef03fae20 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfdc8967a87956c0a7185abbef03fae20)): ?>
<?php $attributes = $__attributesOriginalfdc8967a87956c0a7185abbef03fae20; ?>
<?php unset($__attributesOriginalfdc8967a87956c0a7185abbef03fae20); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfdc8967a87956c0a7185abbef03fae20)): ?>
<?php $component = $__componentOriginalfdc8967a87956c0a7185abbef03fae20; ?>
<?php unset($__componentOriginalfdc8967a87956c0a7185abbef03fae20); ?>
<?php endif; ?>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="bg-[var(--ink)] text-white">
        <div class="section grid gap-10 md:grid-cols-[1.6fr_2.4fr]">
            <div>
                <div class="display-serif text-2xl leading-tight">Guided Wellness</div>
                <p class="mt-3 max-w-sm text-[13px] leading-6 text-white/70">Redefining the supplement experience through transparency, guidance, and respect for biological complexity.</p>
            </div>
            <div class="grid grid-cols-2 gap-6 sm:grid-cols-3">
                <div>
                    <div class="text-[11px] font-medium uppercase tracking-[.16em] text-white/60">Shop</div>
                    <a class="mt-3 block text-[13px] text-white/85 hover:text-white" href="<?php echo e(route('shop')); ?>">30-Day Gut Reset</a>
                    <a class="mt-2 block text-[13px] text-white/85 hover:text-white" href="<?php echo e(route('how-it-works')); ?>">How It Works</a>
                </div>
                <div>
                    <div class="text-[11px] font-medium uppercase tracking-[.16em] text-white/60">Learn</div>
                    <a class="mt-3 block text-[13px] text-white/85 hover:text-white" href="<?php echo e(url('/#learn')); ?>">Guides</a>
                    <a class="mt-2 block text-[13px] text-white/85 hover:text-white" href="<?php echo e(url('/#standards')); ?>">Standards</a>
                    <a class="mt-2 block text-[13px] text-white/85 hover:text-white" href="<?php echo e(url('/#faq')); ?>">About</a>
                </div>
                <div>
                    <div class="text-[11px] font-medium uppercase tracking-[.16em] text-white/60">Support</div>
                    <a class="mt-3 block text-[13px] text-white/85 hover:text-white" href="<?php echo e(route('account')); ?>">Account</a>
                    <a class="mt-2 block text-[13px] text-white/85 hover:text-white" href="<?php echo e(url('/#faq')); ?>">Help Centre</a>
                </div>
            </div>
        </div>
        <div class="border-t border-white/15 py-5 text-center text-[11px] text-white/60">© 2026 Kurate Wellness Private Limited. All rights reserved.</div>
    </footer>
</body>
</html><?php /**PATH C:\xampp\htdocs\gutreset\resources\views/layouts/auth.blade.php ENDPATH**/ ?>