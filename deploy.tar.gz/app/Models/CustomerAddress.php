<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class CustomerAddress extends Model
{
    use HasFactory;
    protected $table = 'customer_addresses';
    protected $guarded = [];
    protected $casts = ['is_default'=>'boolean'];
    public function user() { return $this->belongsTo(User::class); }
}
